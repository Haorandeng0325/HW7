package com.hw7.exercise2;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class InsertActivity extends AppCompatActivity {
  private DatabaseManager dbManager;

  public void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    dbManager = new DatabaseManager( this );
    setContentView( R.layout.activity_insert );
  }

  public void insert( View v ) {
    // Retrieve name and price
    EditText nameEditText = findViewById( R.id.input_name );
    EditText lastNameEditText = findViewById( R.id.input_last_name );
    EditText emailEditText = findViewById( R.id.input_email );
    String name = nameEditText.getText( ).toString( );
    String lastName = lastNameEditText.getText( ).toString( );
    String email = emailEditText.getText( ).toString( );

    // insert new Friend in database
    try {
      Friends friends = new Friends( 0, name, lastName,email );
      dbManager.insert(friends);
      Toast.makeText( this, "Friend added", Toast.LENGTH_SHORT ).show( );
    } catch( NumberFormatException nfe ) {

    }

    // clear data
    nameEditText.setText( "" );
    lastNameEditText.setText( "" );
    emailEditText.setText( "" );
  }

  public void goBack( View v ) {
    this.finish( );
  }
}
