package com.hw7.exercise2;

import android.content.Context;

import androidx.appcompat.widget.AppCompatButton;


public class FriendButton extends AppCompatButton {
  private Friends friends;

  public FriendButton(Context context, Friends newFriends) {
    super( context );
    friends = newFriends;
  }

}
