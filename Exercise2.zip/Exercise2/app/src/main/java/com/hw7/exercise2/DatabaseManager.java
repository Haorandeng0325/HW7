package com.hw7.exercise2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "friendDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_FRIEND = "friend";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String LAST_NAME = "lastname";
    private static final String EMAIL = "email";

    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        // build sql create statement
        String sqlCreate = "create table " + TABLE_FRIEND + "( " + ID;
        sqlCreate += " integer primary key autoincrement, ";
        sqlCreate += NAME+" text, " ;
        sqlCreate += LAST_NAME+" text, " + EMAIL + " text )";
        db.execSQL(sqlCreate);
    }

    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Drop old table if it exists
        db.execSQL("drop table if exists " + TABLE_FRIEND);
        // Re-create tables
        onCreate(db);
    }

    public void insert(Friends friends) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlInsert = "insert into " + TABLE_FRIEND;
        sqlInsert += " values( null, '" + friends.getName( );
        sqlInsert += "', '" + friends.getLastName();
        sqlInsert += "', '" + friends.getEmail( ) + "' )";

        db.execSQL(sqlInsert);
        db.close();
    }

    public void deleteById(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlDelete = "delete from " + TABLE_FRIEND;
        sqlDelete += " where " + ID + " = " + id;

        db.execSQL(sqlDelete);
        db.close();
    }

    public void updateById(int id, String name,String lastName,String email) {
        SQLiteDatabase db = this.getWritableDatabase();

        String sqlUpdate = "update " + TABLE_FRIEND;
        sqlUpdate += " set " + NAME + " = '" + name + "', ";
        sqlUpdate += LAST_NAME + " = '" + lastName + "', ";
        sqlUpdate += EMAIL + " = '" + email + "'";
        sqlUpdate += " where " + ID + " = " + id;

        db.execSQL(sqlUpdate);
        db.close();
    }

    public ArrayList<Friends> selectAll() {
        String sqlQuery = "select * from " + TABLE_FRIEND;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sqlQuery, null);

        ArrayList<Friends> candies = new ArrayList<Friends>();

        while (cursor.moveToNext()) {
            Friends currentFriends;
            currentFriends = new Friends(Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1), cursor.getString(2),cursor.getString(3));

            candies.add(currentFriends);


        }
        db.close();
        return candies;
    }

    public Friends selectById(int id) {
        String sqlQuery = "select * from " + TABLE_FRIEND;
        sqlQuery += " where " + ID + " = " + id;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sqlQuery, null);

        Friends friends = null;
        if (cursor.moveToFirst())
            friends = new Friends(Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1), cursor.getString(2), cursor.getString(3));
        return friends;
    }
}
