package com.hw7.exercise2;

import android.graphics.Point;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity {
  DatabaseManager dbManager;

  public void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    dbManager = new DatabaseManager( this );
    updateView( );
  }

  // Build a View dynamically with all the friendsList
  public void updateView( ) {
    ArrayList<Friends> friendsList = dbManager.selectAll( );
    if( friendsList.size( ) > 0 ) {
      // create ScrollView and GridLayout
      ScrollView scrollView = new ScrollView( this );
      GridLayout grid = new GridLayout( this );
      grid.setRowCount( friendsList.size( ) );
      grid.setColumnCount( 5 );

      // create arrays of components
      TextView [] ids = new TextView[friendsList.size( )];
      EditText [][] namesAndPrices = new EditText[friendsList.size( )][3];
      Button [] buttons = new Button[friendsList.size( )];
      ButtonHandler bh = new ButtonHandler( );

      // retrieve width of screen
      Point size = new Point( );
      getWindowManager( ).getDefaultDisplay( ).getSize( size );
      int width = size.x;

      int i = 0;

      for ( Friends friends : friendsList ) {
        // create the TextView for the friend's id
        ids[i] = new TextView( this );
        ids[i].setGravity( Gravity.CENTER );
        ids[i].setText( "" + friends.getId( ) );

        // create the two EditTexts for the friend's name and price
        namesAndPrices[i][0] = new EditText( this );
        namesAndPrices[i][1] = new EditText( this );
        namesAndPrices[i][2] = new EditText( this );
        namesAndPrices[i][0].setText( friends.getName( ) );
        namesAndPrices[i][1].setText( "" + friends.getLastName( ) );
        namesAndPrices[i][2].setText( "" + friends.getEmail( ) );
        namesAndPrices[i][0].setId( 10 * friends.getId( ) );
        namesAndPrices[i][1].setId( 10 * friends.getId( ) + 1 );
        namesAndPrices[i][2].setId( 10 * friends.getId( ) + 2 );

        // create the button
        buttons[i] = new Button( this );
        buttons[i].setText( "Update" );
        buttons[i].setId( friends.getId( ) );

        // set up event handling
        buttons[i].setOnClickListener( bh );

        // add the elements to grid
        grid.addView( ids[i], width / 10,
                      ViewGroup.LayoutParams.WRAP_CONTENT );
        grid.addView( namesAndPrices[i][0], ( int ) ( width * .15 ),
                      ViewGroup.LayoutParams.WRAP_CONTENT );
        grid.addView( namesAndPrices[i][1], ( int ) ( width * .15 ),
                      ViewGroup.LayoutParams.WRAP_CONTENT );
        grid.addView( namesAndPrices[i][2], ( int ) ( width * .15 ),
                ViewGroup.LayoutParams.WRAP_CONTENT );
        grid.addView( buttons[i], ( int ) ( width * .35 ),
                      ViewGroup.LayoutParams.WRAP_CONTENT );

        i++;
      }
      scrollView.addView( grid );
      setContentView( scrollView );
    }
  }

  private class ButtonHandler implements View.OnClickListener {
    public void onClick( View v ) {
      // retrieve name and lastname,email of the friend
      int friendId = v.getId( );
      EditText nameET = findViewById( 10 * friendId );
      EditText lastET = findViewById( 10 * friendId + 1 );
      EditText emailET = findViewById( 10 * friendId + 2 );
      String name = nameET.getText( ).toString( );
      String lastName = lastET.getText( ).toString( );
      String email = emailET.getText( ).toString( );

      // update friend in database
      try {
        dbManager.updateById( friendId, name, lastName,email );
        Toast.makeText( UpdateActivity.this, "Friend updated",
          Toast.LENGTH_SHORT ).show( );

        // update screen
        updateView( );
      } catch( NumberFormatException nfe ) {
        Toast.makeText( UpdateActivity.this,
                        "Price error", Toast.LENGTH_LONG ).show( );
      }
    }
  }
}
