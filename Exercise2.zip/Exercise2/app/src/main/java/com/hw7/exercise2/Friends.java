package com.hw7.exercise2;

public class Friends {
  private int id;
  private String name;
  private String lastName;
  private String email;

  public Friends(int newId, String newName, String newLastName,String newEmail ) {
    setId( newId );
    setName(newName);
    setLastName(newLastName);
    setEmail(newEmail);
  }

  public void setId( int newId ) {
    id = newId;
  }

  public void setName( String newName ) {
    name = newName;
  }

  public int getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }
}