package com.hw7.exercise2;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.graphics.Point;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
  private DatabaseManager dbManager;
  private ScrollView scrollView;
  private int buttonWidth;

  @Override
  protected void onCreate( Bundle savedInstanceState ) {
    super.onCreate( savedInstanceState );
    setContentView( R.layout.activity_main );
    Toolbar toolbar = findViewById( R.id.toolbar );
    setSupportActionBar( toolbar );
    dbManager = new DatabaseManager( this );
    scrollView = findViewById( R.id.scrollView );
    Point size = new Point( );
    getWindowManager( ).getDefaultDisplay( ).getSize( size );
    buttonWidth = size.x;
    updateView( );
  }

  protected void onResume( ) {
    super.onResume( );
    updateView( );
  }

  public void updateView( ) {
    ArrayList<Friends> candies = dbManager.selectAll( );
    if( candies.size( ) > 0 ) {
      // remove subviews inside scrollView if necessary
      scrollView.removeAllViewsInLayout( );

      // set up the grid layout
      GridLayout grid = new GridLayout( this );
      grid.setRowCount( ( candies.size( ) + 1 ) / 2 );
      grid.setColumnCount( 1 );

      // create array of buttons, 2 per row
      FriendButton[] buttons = new FriendButton[candies.size( )];

      // fill the grid
      int i = 0;
      for ( Friends friends : candies ) {
        // create the button
        buttons[i] = new FriendButton( this, friends);
        buttons[i].setText( "name:"+friends.getName( )
            + "\n" +"lastName:" +friends.getLastName( )+"\n"
                +"Email:"+friends.getEmail() );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          buttons[i].setTextColor(getColor(R.color.colorPrimary));
          buttons[i].setBackgroundColor(getColor(R.color.white));
        }

        // add the button to grid
        grid.addView( buttons[i], buttonWidth,
            GridLayout.LayoutParams.WRAP_CONTENT );
        i++;
      }
      scrollView.addView( grid );
    }
  }

  @Override
  public boolean onCreateOptionsMenu( Menu menu ) {
    getMenuInflater( ).inflate( R.menu.menu_main, menu );
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId( );
    switch ( id ) {
      case R.id.action_add:
        Intent insertIntent
          = new Intent( this, InsertActivity.class );
        this.startActivity( insertIntent );
        return true;
      case R.id.action_delete:
        Intent deleteIntent
          = new Intent( this, DeleteActivity.class );
        this.startActivity( deleteIntent );
        return true;
      case R.id.action_update:
        Intent updateIntent
          = new Intent( this, UpdateActivity.class );
        this.startActivity( updateIntent );
        return true;
      case R.id.action_exit:
        this.finish();
        return true;
      default:
        return super.onOptionsItemSelected( item );
    }
  }

}
