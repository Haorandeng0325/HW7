package com.hw7.exercise4;



public class StringUtil {
    //转换为String
    public static String getMultiNumber(int number) {
        return number < 10 ? "0" + number : Integer.toString(number);
    }

    public static String getLocalMonth(int month) {
        return getMultiNumber(month + 1);
    }

}
