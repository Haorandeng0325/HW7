package com.hw7.exercise4;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.List;


public class MainActivity extends AppCompatActivity {


    ListView listview;

     HelperSQLite helperSQLite;
    List< UserInfo> list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //使用ToolBar
        Toolbar toolbar = findViewById( R.id.toolbar );
        setSupportActionBar( toolbar );
        helperSQLite=new  HelperSQLite(this);
        showQueryData();
    }

    //显示所有的数据
    private void showQueryData(){
        listview = findViewById(R.id.listview);
        if (list!=null){
            list.clear();
        }
        list=helperSQLite.query();
        listview.setAdapter(new NotePadAdapter(this,list));
        listview.setOnItemClickListener(new NotePadOnItemClickListener(this,list));
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1){
            if (resultCode==2){
                showQueryData();
            }
        }
    }

    //创建菜单
    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater( ).inflate( R.menu.menu_main, menu );
        return true;
    }

    //menu点击事项
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId( );
        switch ( id ) {
            case R.id.action_add:
                startActivityForResult(new Intent(MainActivity.this,  FunctionActivity.class),1);
                return true;
            case R.id.action_exit:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }
}
