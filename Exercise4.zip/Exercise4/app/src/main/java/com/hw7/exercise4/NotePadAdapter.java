package com.hw7.exercise4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;

//adapter
public class NotePadAdapter extends BaseAdapter {

    private LayoutInflater layoutInflater;

    private List<UserInfo> list;
    Context context;

    public NotePadAdapter(Context context, List<UserInfo> list){
        this.layoutInflater=LayoutInflater.from(context);
        this.list=list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list==null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //数据显示
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView==null){
            convertView=layoutInflater.inflate(R.layout.notepad_item_layout,null);
            viewHolder=new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else {
            viewHolder=(ViewHolder) convertView.getTag();
        }
        UserInfo userInfo=(UserInfo) getItem(position);
        Calendar calendar = Calendar.getInstance();
        String format = "yyyy-MM-dd HH:mm:ss";
        long currentTime = DateUtils.date2TimeStamp(String.format("%s-%s-%s %s", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH)+1, calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE)),"yyyy-MM-dd HH:mm");
        viewHolder.tvNotepadYear.setText(userInfo.getUserYear());
        viewHolder.tvNoteoadContent.setText(userInfo.getUserContent());
        viewHolder.tvNoteoadTime.setText(userInfo.getUserTime());
        viewHolder.tvNoteoadTime.setVisibility(View.GONE);
        if(currentTime > DateUtils.date2TimeStamp(userInfo.getUserYear()+":00",format)){
            viewHolder.tvNotepadYear.setTextColor(context.getResources().getColor(R.color.red));
            viewHolder.tvNoteoadContent.setTextColor(context.getResources().getColor(R.color.red));
            viewHolder.tvNoteoadTime.setTextColor(context.getResources().getColor(R.color.red));
        }

        return convertView;
    }

    class ViewHolder{
        TextView tvNotepadYear;
        TextView tvNoteoadContent;
        TextView tvNoteoadTime;
        public ViewHolder(View view){
            tvNotepadYear=(TextView) view.findViewById(R.id.notepad_item_year);
            tvNoteoadContent=(TextView) view.findViewById(R.id.notepad_item_content);
            tvNoteoadTime=(TextView) view.findViewById(R.id.notepad_item_time);
        }
    }

}
