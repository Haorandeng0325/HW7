package com.hw7.exercise4;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;

import java.util.List;

//todolist列表的点击事件
public class NotePadOnItemClickListener implements AdapterView.OnItemClickListener {

    private List< UserInfo> list;
    private  MainActivity mainActivity;
    public NotePadOnItemClickListener( MainActivity mainActivity, List< UserInfo> list) {
        this.mainActivity=mainActivity;
        this.list=list;
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
         UserInfo userInfo=list.get(position);
        Intent intent=new Intent(mainActivity,  FunctionActivity.class);
        intent.putExtra("id",userInfo.getId());
        intent.putExtra("year",userInfo.getUserYear());
        intent.putExtra("content",userInfo.getUserContent());
        intent.putExtra("time",userInfo.getUserTime());
        mainActivity.startActivityForResult(intent,1);
    }
}
