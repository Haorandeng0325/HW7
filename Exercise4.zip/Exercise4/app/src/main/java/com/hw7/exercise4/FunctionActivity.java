package com.hw7.exercise4;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Calendar;


public class FunctionActivity extends AppCompatActivity{

    EditText notepadContent;
    TextView untilTime;

    String todoId;
    HelperSQLite helperSQLite;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.function_layout);
        Toolbar toolbar = findViewById( R.id.toolbar );
        untilTime = findViewById(R.id.todo_data);
        untilTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();
                DatePickerDialog dialog = new DatePickerDialog(FunctionActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, final int year, final int month, final int dayOfMonth) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(FunctionActivity.this, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                String time = year + "-" + StringUtil.getLocalMonth(month) + "-" + StringUtil.getMultiNumber(dayOfMonth) + " " + StringUtil.getMultiNumber(hourOfDay) + ":" + StringUtil.getMultiNumber(minute);
                                untilTime.setText(time);
                            }
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);
                        timePickerDialog.show();
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                dialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
                dialog.show();
            }
        });
        setSupportActionBar(toolbar);
        notepadContent = findViewById(R.id.notepad_content);
        Intent intent=getIntent();
        if(intent!= null){
            todoId=intent.getStringExtra("id");
            if (todoId!=null){
                notepadContent.setText(intent.getStringExtra("content"));
            }else {
            }
        }else {
        }
        helperSQLite=new HelperSQLite(this);
    }



    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater( ).inflate( R.menu.menu_edit, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId( );
        switch ( id ) {
            case R.id.action_delete:
                if (todoId!=null){
                    if (helperSQLite.deleteData(todoId)){
                        Toast.makeText(this,"delete success!",Toast.LENGTH_SHORT).show();
                        setResult(2);
                        finish();
                    }else {
                        Toast.makeText(this,"delete fail!",Toast.LENGTH_SHORT).show();
                    }
                }else {
                    notepadContent.setText("");
                }
                return true;
            case R.id.action_update:
                String noteContent=notepadContent.getText().toString().trim();
                if (todoId!=null){//修改操作
                    if (noteContent.length()>0){
                        if (helperSQLite.updateData(todoId,noteContent,untilTime.getText().toString(),  UtilDB.shoTime())){
                            Toast.makeText(this,"modify success!",Toast.LENGTH_SHORT).show();
                            setResult(2);
                            finish();
                        }else {
                            Toast.makeText(this,"modify fail!",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(this,"can not error!",Toast.LENGTH_SHORT).show();
                    }
                }else {//添加
                    if (noteContent.length()>0){

                        if (helperSQLite.insertDate(noteContent,untilTime.getText().toString(),  UtilDB.shoTime())){
                            Toast.makeText(this,"add success!",Toast.LENGTH_SHORT).show();
                            setResult(2);
                            finish();
                        }else {
                            Toast.makeText(this,"add fail!",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(this,"add fail!",Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            case R.id.action_exit:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }
}
