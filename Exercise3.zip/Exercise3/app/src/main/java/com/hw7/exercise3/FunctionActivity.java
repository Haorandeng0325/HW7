package com.hw7.exercise3;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


public class FunctionActivity extends AppCompatActivity{

    EditText notepadContent;

    String todoId;
    HelperSQLite helperSQLite;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.function_layout);
        Toolbar toolbar = findViewById( R.id.toolbar );
        setSupportActionBar(toolbar);
        notepadContent = findViewById(R.id.notepad_content);
        Intent intent=getIntent();
        if(intent!= null){
            todoId=intent.getStringExtra("id");
            if (todoId!=null){
                notepadContent.setText(intent.getStringExtra("content"));
            }else {
            }
        }else {
        }
        helperSQLite=new HelperSQLite(this);
    }



    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater( ).inflate( R.menu.menu_edit, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId( );
        switch ( id ) {
            case R.id.action_delete:
                if (todoId!=null){
                    if (helperSQLite.deleteData(todoId)){
                        Toast.makeText(this,"delete success!",Toast.LENGTH_SHORT).show();
                        setResult(2);
                        finish();
                    }else {
                        Toast.makeText(this,"delete fail!",Toast.LENGTH_SHORT).show();
                    }
                }else {
                    notepadContent.setText("");
                }
                return true;
            case R.id.action_update:
                String noteContent=notepadContent.getText().toString().trim();
                if (todoId!=null){//修改操作
                    if (noteContent.length()>0){
                        if (helperSQLite.updateData(todoId,noteContent, UtilDB.shoTimeYear(),UtilDB.shoTime())){
                            Toast.makeText(this,"modify success!",Toast.LENGTH_SHORT).show();
                            setResult(2);
                            finish();
                        }else {
                            Toast.makeText(this,"modify fail!",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(this,"can not error!",Toast.LENGTH_SHORT).show();
                    }
                }else {//添加
                    if (noteContent.length()>0){

                        if (helperSQLite.insertDate(noteContent, UtilDB.shoTimeYear(),UtilDB.shoTime())){
                            Toast.makeText(this,"add success!",Toast.LENGTH_SHORT).show();
                            setResult(2);
                            finish();
                        }else {
                            Toast.makeText(this,"add fail!",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(this,"add fail!",Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            case R.id.action_exit:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }
}
